package com.example.timerapp41;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Chronometer chronometer;
    boolean running, pause;
    TextView textView1, textView2;
    long time, pauperise;
    String setback, edited,editTxt, timer;
    EditText edit;
    SharedPreferences sharedPreferences,shared2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        chronometer = findViewById(R.id.chronometer);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        edit = findViewById(R.id.edit);
        shared2 = getSharedPreferences("com.example.timerapp41", MODE_PRIVATE);
        sharedPreferences = getSharedPreferences("com.example.timerapp41", MODE_PRIVATE);
        checkSharedPreferences();
        if (savedInstanceState != null)
        {
            editTxt = savedInstanceState.getString("edited");

            pauperise = savedInstanceState.getLong("pause");
            time = savedInstanceState.getLong("times");
            running = savedInstanceState.getBoolean("continue");
            setback = savedInstanceState.getString("settime");

            if(running)
            {
                chronometer.setBase(time);
                chronometer.start();
            }
            if (!running)
            {
                long seconds = (pauperise / 1000) % 60;
                long minutes = (pauperise / 1000) / 60;
                long hours = (pauperise / 1000) / 3600;
                chronometer.setText(String.format("%02d:%02d",minutes,seconds));
            }


        }
        if (editTxt!=null)
            edit.setText(editTxt);
        editTxt = edit.getText().toString();
    }

    public void checkSharedPreferences() {
        if (editTxt!=null)
            edit.setText(editTxt);
        editTxt = edit.getText().toString();

        String last_time = shared2.getString(timer,"");
        textView1.setText("You spent " + last_time + " on " + editTxt+ " last time");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("edited", edit.getText().toString());
        outState.putBoolean("continue", running);
        outState.putLong("pause", pauperise);
        outState.putLong("times", time);
        outState.putString("settime", setback);


    }


    public void start(View view) {
        switch (view.getId()) {
            case R.id.start:
                if (!running) {
                    chronometer.setBase(SystemClock.elapsedRealtime() - pauperise);
                    chronometer.start();
                    time = SystemClock.elapsedRealtime() - pauperise;
                    running = true;
                }
                break;

            case R.id.pause:
                if (running) {
                    chronometer.stop();
                    pauperise = SystemClock.elapsedRealtime() - chronometer.getBase();
                    running = false;
                    pause = false;
                }
                break;

            case R.id.stop:
                if (running) {
                    chronometer.stop();
                    pauperise = SystemClock.elapsedRealtime() - chronometer.getBase();
                    long second = (pauperise / 1000) % 60;
                    long minute = (pauperise / 1000) / 60;
                    long hour = (pauperise / 1000) / 3600;
                    setback = String.format("%02d:%02d:%02d", hour, minute, second);
                    running = false;
                } else {
                    if (!pause) {
                        long seconds = (pauperise / 1000) % 60;
                        long minutes = (pauperise / 1000) / 60;
                        long hours = (pauperise / 1000) / 3600;
                        setback = String.format("%02d:%02d:%02d", hours, minutes, seconds);
                        pause = true;
                    }

                }


                chronometer.setBase(SystemClock.elapsedRealtime());
                pauperise = 0;
                running = false;
                textView1.setText("You spent " + setback + " on " + edit.getText().toString() + " last time");


                SharedPreferences.Editor editor1 = shared2.edit();
                editor1.putString(timer, setback);

                editor1.commit();

                editor1.apply();


                break;

            default:
                throw new IllegalStateException("Unexpected Value: " + view.getId());
        }
    }

}